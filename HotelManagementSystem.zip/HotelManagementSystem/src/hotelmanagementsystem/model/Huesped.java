package hotelmanagementsystem.model;

public class Huesped {
    private String nombre;
    private String documento;
    private String telefono;
    private String email;
    private Habitacion habitacion;
    private int noches;

    public Huesped(String nombre, String documento, String telefono, String email, Habitacion habitacion, int noches) {
        this.nombre = nombre;
        this.documento = documento;
        this.telefono = telefono;
        this.email = email;
        this.habitacion = habitacion;
        this.noches = noches;
    }

    public String getNombre() { return nombre; }
    public String getDocumento() { return documento; }
    public String getTelefono() { return telefono; }
    public String getEmail() { return email; }
    public Habitacion getHabitacion() { return habitacion; }
    public int getNoches() { return noches; }

    @Override
    public String toString() {
        return nombre + " | Doc: " + documento + " | Hab: " + (habitacion != null ? habitacion.getNumero() : "N/A");
    }
}
