package hotelmanagementsystem.model;

public class Suite extends Habitacion {
    public Suite(int numero, int piso) { super(numero, piso, 3, 150000); }
}
