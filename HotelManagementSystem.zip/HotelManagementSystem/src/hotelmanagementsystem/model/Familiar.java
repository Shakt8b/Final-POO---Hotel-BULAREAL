package hotelmanagementsystem.model;

public class Familiar extends Habitacion {
    public Familiar(int numero, int piso) { super(numero, piso, 4, 120000); }
}
