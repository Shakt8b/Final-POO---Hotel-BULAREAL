package hotelmanagementsystem.model;

import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Reserva {
    private static int contadorDiario = 1; // Contador para el día
    private String id;
    private String nombreCliente;
    private String documento;
    private String telefono;
    private String email;
    private Habitacion habitacion;
    private int noches;
    private int personas;
    private PagoInfo pago;
    private List<Servicio> adicionales;

    public Reserva(String nombreCliente, String documento, String telefono, String email,
                   Habitacion habitacion, int noches, int personas, PagoInfo pago) {

        // ID basado en fecha: RES-YYYYMMDD-001
        String fecha = new SimpleDateFormat("yyyyMMdd").format(new Date());
        this.id = String.format("RES-%s-%03d", fecha, contadorDiario++);
        
        this.nombreCliente = nombreCliente;
        this.documento = documento;
        this.telefono = telefono;
        this.email = email;
        this.habitacion = habitacion;
        this.noches = noches;
        this.personas = personas;
        this.pago = pago;
        this.adicionales = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getNombreCliente() { return nombreCliente; }
    public String getDocumento() { return documento; }
    public String getTelefono() { return telefono; }
    public String getEmail() { return email; }
    public Habitacion getHabitacion() { return habitacion; }
    public int getNoches() { return noches; }
    public int getPersonas() { return personas; }
    public PagoInfo getPago() { return pago; }
    public List<Servicio> getAdicionales() { return adicionales; }
    public void agregarServicio(Servicio s) { adicionales.add(s); }

    @Override
    public String toString() {
        return "Reserva " + id + " | " + nombreCliente + " | Hab:" + (habitacion != null ? habitacion.getNumero() : "N/A") +
               " | Noches:" + noches + " | Pers:" + personas;
    }
}
