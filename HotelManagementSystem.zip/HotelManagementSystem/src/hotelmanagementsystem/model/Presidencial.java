package hotelmanagementsystem.model;

public class Presidencial extends Habitacion {
    public Presidencial(int numero, int piso) { super(numero, piso, 5, 350000); }
}
