package hotelmanagementsystem.model;

public class PagoInfo {
    private String metodo;  // Efectivo, Tarjeta, Transferencia
    private String tarjetaNumero;
    private String tarjetaNombre;
    private String tarjetaCVV;
    private String bancoTransferencia;
    private String referenciaTransferencia;

    public PagoInfo(String metodo) {
        this.metodo = metodo;
    }

    public String getMetodo() { return metodo; }

    public String getTarjetaNumero() { return tarjetaNumero; }
    public void setTarjetaNumero(String tarjetaNumero) { this.tarjetaNumero = tarjetaNumero; }

    public String getTarjetaNombre() { return tarjetaNombre; }
    public void setTarjetaNombre(String tarjetaNombre) { this.tarjetaNombre = tarjetaNombre; }

    public String getTarjetaCVV() { return tarjetaCVV; }
    public void setTarjetaCVV(String tarjetaCVV) { this.tarjetaCVV = tarjetaCVV; }

    public String getBancoTransferencia() { return bancoTransferencia; }
    public void setBancoTransferencia(String bancoTransferencia) { this.bancoTransferencia = bancoTransferencia; }

    public String getReferenciaTransferencia() { return referenciaTransferencia; }
    public void setReferenciaTransferencia(String referenciaTransferencia) { this.referenciaTransferencia = referenciaTransferencia; }
}
