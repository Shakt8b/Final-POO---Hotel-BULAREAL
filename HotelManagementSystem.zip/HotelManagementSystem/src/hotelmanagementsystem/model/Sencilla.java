package hotelmanagementsystem.model;

public class Sencilla extends Habitacion {
    public Sencilla(int numero, int piso) { super(numero, piso, 1, 50000); }
}
