package hotelmanagementsystem.model;

public class Doble extends Habitacion {
    public Doble(int numero, int piso) { super(numero, piso, 2, 80000); }
}

