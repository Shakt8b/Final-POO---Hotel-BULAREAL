package hotelmanagementsystem.model;

public abstract class Habitacion {
    private int numero;
    private int piso;
    private int capacidad;
    private double precio;
    private boolean ocupada;

    public Habitacion(int numero, int piso, int capacidad, double precio) {
        this.numero = numero;
        this.piso = piso;
        this.capacidad = capacidad;
        this.precio = precio;
        this.ocupada = false;
    }

    public int getNumero() { return numero; }
    public int getPiso() { return piso; }
    public int getCapacidad() { return capacidad; }
    public double getPrecio() { return precio; }
    public boolean isOcupada() { return ocupada; }
    public void setOcupada(boolean ocupada) { this.ocupada = ocupada; }

    public void setPrecio(double precio) { this.precio = precio; }
    public void setPiso(int piso) { this.piso = piso; }
    public void setCapacidad(int capacidad) { this.capacidad = capacidad; }

    @Override
    public String toString() {
        return numero + " - " + this.getClass().getSimpleName() + " | Piso " + piso +
                " | Cap: " + capacidad + " | $" + precio + (ocupada ? " [OCUPADA]" : "");
    }
}
