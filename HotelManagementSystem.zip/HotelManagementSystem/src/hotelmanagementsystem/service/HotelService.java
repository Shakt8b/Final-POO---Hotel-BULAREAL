package hotelmanagementsystem.service;

public class HotelService {

}
