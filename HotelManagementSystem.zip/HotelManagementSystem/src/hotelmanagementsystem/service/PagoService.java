package hotelmanagementsystem.service;

public class PagoService {

}
