package hotelmanagementsystem.service;

import hotelmanagementsystem.model.*;
import hotelmanagementsystem.datos.*;

import java.util.List;

public class ReservaService {
    public Reserva crearReserva(String nombre, String documento, String telefono, String email,
                                int numeroHabitacion, int noches, int personas, PagoInfo pago) {
        Habitacion h = HabitacionDatos.buscar(numeroHabitacion);
        if (h == null) throw new IllegalArgumentException("Habitación no existe");
        if (h.isOcupada()) throw new IllegalStateException("Habitación ocupada");
        if (h.getCapacidad() < personas) throw new IllegalStateException("Capacidad insuficiente");

        Reserva r = new Reserva(nombre, documento, telefono, email, h, noches, personas, pago);
        ReservaDatos.agregar(r);
        HabitacionDatos.marcarOcupada(h.getNumero(), true);
        return r;
    }

    public List<Reserva> listarReservas() { return ReservaDatos.obtenerTodas(); }

    public void cancelarReserva(String id) {
        Reserva r = ReservaDatos.buscarPorId(id);
        if (r != null) {
            HabitacionDatos.marcarOcupada(r.getHabitacion().getNumero(), false);
            ReservaDatos.eliminarPorId(id);
        }
    }
}
