package hotelmanagementsystem.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import hotelmanagementsystem.model.Huesped;
import hotelmanagementsystem.model.Servicio;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

public class FacturaService {

    // Factura Check-Out
    public String generarFacturaCheckOut(Huesped h, List<Servicio> servicios, String metodoPago) {
        try {
            String ruta = System.getProperty("user.home") + "/Desktop/Factura_" + h.getNombre() + ".pdf";
            Document doc = new Document();
            PdfWriter.getInstance(doc, new FileOutputStream(new File(ruta)));
            doc.open();

            Font title = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD);
            doc.add(new Paragraph("HOTEL BULAREAL - FACTURA CHECK-OUT", title));
            doc.add(new Paragraph("Cliente: " + h.getNombre()));
            doc.add(new Paragraph("Habitación: " + h.getHabitacion().getNumero()));
            doc.add(new Paragraph("Noches: " + h.getNoches()));
            doc.add(new Paragraph("Método de pago: " + metodoPago));
            doc.add(new Paragraph(" "));

            PdfPTable tabla = new PdfPTable(2);
            tabla.setWidthPercentage(100);
            tabla.addCell("Concepto");
            tabla.addCell("Valor");

            double total = h.getHabitacion().getPrecio() * h.getNoches();
            tabla.addCell("Alojamiento (" + h.getHabitacion().getClass().getSimpleName() + ")");
            tabla.addCell(String.format("$%.2f", h.getHabitacion().getPrecio() * h.getNoches()));

            for (Servicio s : servicios) {
                tabla.addCell(s.getNombre());
                tabla.addCell(String.format("$%.2f", s.getPrecio()));
                total += s.getPrecio();
            }

            doc.add(tabla);
            doc.add(new Paragraph(" "));
            doc.add(new Paragraph(String.format("TOTAL: $%.2f", total), new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD)));

            doc.close();
            return ruta;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
