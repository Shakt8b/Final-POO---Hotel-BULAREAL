package hotelmanagementsystem.interfaz;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    public VentanaPrincipal() {
        setTitle("HOTEL BULAREAL");
        setSize(420, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 245, 245)); // Fondo claro profesional

        // Nombre del hotel
        JLabel lbl = new JLabel("HOTEL BULAREAL", SwingConstants.CENTER);
        lbl.setBounds(20, 20, 380, 60);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lbl.setForeground(new Color(50, 50, 50));
        add(lbl);

        // Crear botones redondeados
        RoundedButton btnReserva = new RoundedButton("Hacer Reserva", new Color(70, 130, 180));
        btnReserva.setBounds(110, 100, 200, 40);

        RoundedButton btnCheckIn = new RoundedButton("Check-In", new Color(70, 130, 180));
        btnCheckIn.setBounds(110, 160, 200, 40);

        RoundedButton btnCheckOut = new RoundedButton("Check-Out", new Color(70, 130, 180));
        btnCheckOut.setBounds(110, 220, 200, 40);

        RoundedButton btnHabit = new RoundedButton("Gestionar Habitaciones", new Color(70, 130, 180));
        btnHabit.setBounds(110, 280, 200, 40);

        RoundedButton btnServ = new RoundedButton("Servicios", new Color(70, 130, 180));
        btnServ.setBounds(110, 340, 200, 40);

        RoundedButton btnSalir = new RoundedButton("Salir", new Color(220, 53, 69));
        btnSalir.setBounds(110, 400, 200, 40);

        // Agregar botones
        add(btnReserva);
        add(btnCheckIn);
        add(btnCheckOut);
        add(btnHabit);
        add(btnServ);
        add(btnSalir);

        // Acciones
        btnReserva.addActionListener(e -> new FormReserva().setVisible(true));
        btnHabit.addActionListener(e -> new FormHabitaciones().setVisible(true));
        btnCheckIn.addActionListener(e -> new FormCheckIn().setVisible(true));
        btnCheckOut.addActionListener(e -> new FormCheckOut().setVisible(true));
        btnServ.addActionListener(e -> new FormServicios().setVisible(true));
        btnSalir.addActionListener(e -> System.exit(0));
    }

    // Clase interna para botones totalmente redondeados
    private static class RoundedButton extends JButton {
        private Color backgroundColor;

        public RoundedButton(String text, Color bg) {
            super(text);
            backgroundColor = bg;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(backgroundColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 40, 40); // Redondeado completo
            super.paintComponent(g2);
            g2.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(backgroundColor.darker());
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            g2.dispose();
        }

        @Override
        public boolean isContentAreaFilled() {
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}
