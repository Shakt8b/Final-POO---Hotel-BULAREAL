package hotelmanagementsystem.interfaz;

import hotelmanagementsystem.datos.ServicioDatos;
import hotelmanagementsystem.model.Servicio;

import javax.swing.*;
import java.awt.*;

public class FormServicios extends JFrame {

    private DefaultListModel<Servicio> modelo;
    private JList<Servicio> lista;

    public FormServicios() {
        setTitle("Servicios");
        setSize(420,360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(6,6));

        modelo = new DefaultListModel<>();
        lista = new JList<>(modelo);
        cargar();

        JPanel bot = new JPanel();
        JButton btnAdd = new JButton("Agregar Servicio");
        btnAdd.addActionListener(e -> agregar());
        bot.add(btnAdd);

        add(new JScrollPane(lista), BorderLayout.CENTER);
        add(bot, BorderLayout.SOUTH);
    }

    private void cargar() {
        modelo.clear();
        for (Servicio s : ServicioDatos.obtenerTodos()) modelo.addElement(s);
    }

    private void agregar() {
        String nombre = JOptionPane.showInputDialog(this, "Nombre servicio:");
        if (nombre == null || nombre.isBlank()) return;
        String precioStr = JOptionPane.showInputDialog(this, "Precio:");
        if (precioStr == null) return;
        double precio = Double.parseDouble(precioStr);
        ServicioDatos.agregar(new Servicio(nombre, precio));
        cargar();
    }
}
