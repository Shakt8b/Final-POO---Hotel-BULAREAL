package hotelmanagementsystem.interfaz;

import hotelmanagementsystem.datos.HuespedDatos;
import hotelmanagementsystem.datos.HabitacionDatos;
import hotelmanagementsystem.model.Huesped;
import hotelmanagementsystem.model.Servicio;
import hotelmanagementsystem.service.FacturaService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class FormCheckOut extends JFrame {

    private JComboBox<String> cbHuespedes;
    private JPanel panelServicios;
    private List<JCheckBox> checkBoxesServicios;

    public FormCheckOut() {
        setTitle("Check-Out - HOTEL BULAREAL");
        setSize(550, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        cbHuespedes = new JComboBox<>();
        cargarHuespedes();

        panelServicios = new JPanel();
        panelServicios.setLayout(new BoxLayout(panelServicios, BoxLayout.Y_AXIS));
        checkBoxesServicios = new ArrayList<>();
        cargarServicios();

        JButton btnProcesar = new JButton("Procesar Check-Out");
        btnProcesar.setBackground(new Color(34, 139, 230));
        btnProcesar.setForeground(Color.WHITE);
        btnProcesar.setFocusPainted(false);
        btnProcesar.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btnProcesar.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel top = new JPanel(new GridLayout(2, 1, 5, 5));
        JLabel lblTitulo = new JLabel("HOTEL BULAREAL", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 28));
        lblTitulo.setForeground(new Color(34, 139, 230));
        top.add(lblTitulo);
        top.add(cbHuespedes);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(panelServicios), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        bottom.add(btnProcesar);
        add(bottom, BorderLayout.SOUTH);

        btnProcesar.addActionListener(e -> procesarCheckOut());
    }

    private void cargarHuespedes() {
        cbHuespedes.removeAllItems();
        var lista = HuespedDatos.obtenerTodos();
        if (lista.isEmpty()) {
            cbHuespedes.addItem("No hay huéspedes");
        }
        for (Huesped h : lista) {
            cbHuespedes.addItem(h.getNombre() + " | Hab: " + h.getHabitacion().getNumero());
        }
    }

    private void cargarServicios() {
        checkBoxesServicios.clear();
        panelServicios.removeAll();

        // Servicios generales
        List<Servicio> serviciosGenerales = List.of(
                new Servicio("Minibar", 20000),
                new Servicio("Lavandería", 15000),
                new Servicio("Spa", 60000),
                new Servicio("Piscina VIP", 35000)
        );

        JPanel panelGeneral = crearPanelServicio("Servicios Generales", serviciosGenerales);
        panelServicios.add(panelGeneral);

        // Servicios de comida
        List<Servicio> serviciosComida = List.of(
                new Servicio("Brunch", 30000),
                new Servicio("Almuerzo", 45000),
                new Servicio("Cena", 50000),
                new Servicio("Snacks y Bebidas", 20000)
        );

        JPanel panelComida = crearPanelServicio("Servicios de Comida y Snacks", serviciosComida);
        panelServicios.add(panelComida);

        panelServicios.revalidate();
        panelServicios.repaint();
    }

    private JPanel crearPanelServicio(String titulo, List<Servicio> servicios) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder(titulo));
        panel.setBackground(new Color(245, 245, 245));
        panel.setOpaque(true);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        for (Servicio s : servicios) {
            JCheckBox cb = new JCheckBox(s.getNombre() + " - $" + s.getPrecio());
            cb.setBackground(new Color(245, 245, 245));
            cb.setFont(new Font("Arial", Font.PLAIN, 14));
            cb.setFocusPainted(false);
            cb.setBorder(new EmptyBorder(5, 10, 5, 10));
            checkBoxesServicios.add(cb);
            panel.add(cb);
        }

        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(titulo),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        return panel;
    }

    private void procesarCheckOut() {
        try {
            int idx = cbHuespedes.getSelectedIndex();
            if (idx < 0) return;

            Huesped h = HuespedDatos.obtenerTodos().get(idx);

            // --- Pide confirmación/edición de datos del huésped ---
            JPanel panelDatos = new JPanel(new GridLayout(3, 2, 5, 5));
            JTextField txtNombre = new JTextField(h.getNombre());
            JTextField txtDocumento = new JTextField(h.getDocumento());
            JTextField txtTelefono = new JTextField(h.getTelefono());

            panelDatos.add(new JLabel("Nombre:"));
            panelDatos.add(txtNombre);
            panelDatos.add(new JLabel("Documento:"));
            panelDatos.add(txtDocumento);
            panelDatos.add(new JLabel("Teléfono:"));
            panelDatos.add(txtTelefono);

            int opcion = JOptionPane.showConfirmDialog(this, panelDatos,
                    "Confirme datos del huésped", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (opcion != JOptionPane.OK_OPTION) return;

            // Actualizar datos del huésped
            h = new Huesped(txtNombre.getText().trim(),
                    txtDocumento.getText().trim(),
                    txtTelefono.getText().trim(),
                    h.getEmail(),
                    h.getHabitacion(),
                    h.getNoches());

            // Obtener servicios seleccionados
            List<Servicio> serviciosSeleccionados = new ArrayList<>();
            List<Servicio> serviciosTodos = List.of(
                    new Servicio("Minibar", 20000),
                    new Servicio("Lavandería", 15000),
                    new Servicio("Spa", 60000),
                    new Servicio("Piscina VIP", 35000),
                    new Servicio("Brunch", 30000),
                    new Servicio("Almuerzo", 45000),
                    new Servicio("Cena", 50000),
                    new Servicio("Snacks y Bebidas", 20000)
            );
            for (int i = 0; i < checkBoxesServicios.size(); i++) {
                if (checkBoxesServicios.get(i).isSelected()) {
                    serviciosSeleccionados.add(serviciosTodos.get(i));
                }
            }

            // Elegir método de pago
            String[] met = {"Efectivo", "Tarjeta Crédito", "Tarjeta Débito", "Transferencia"};
            String metodo = (String) JOptionPane.showInputDialog(this, "Seleccione método de pago:", "Pago",
                    JOptionPane.QUESTION_MESSAGE, null, met, met[0]);
            if (metodo == null) return;

            // Generar factura
            FacturaService fs = new FacturaService();
            String rutaFactura = fs.generarFacturaCheckOut(h, serviciosSeleccionados, metodo);

            // Abrir WhatsApp
            try {
                String telefono = h.getTelefono().replaceAll("[^0-9]", "");
                String mensaje = "¡Hola " + h.getNombre() + "! Aquí tienes tu factura de estadía. Gracias por hospedarte con nosotros.";
                String url = "https://wa.me/57" + telefono + "?text=" + java.net.URLEncoder.encode(mensaje, "UTF-8");
                java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "No se pudo abrir WhatsApp.");
            }

            HabitacionDatos.marcarOcupada(h.getHabitacion().getNumero(), false);
            HuespedDatos.eliminar(h);

            JOptionPane.showMessageDialog(this, "Check-Out completado.");

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error en proceso de Check-Out: " + ex.getMessage());
        }
    }
}
