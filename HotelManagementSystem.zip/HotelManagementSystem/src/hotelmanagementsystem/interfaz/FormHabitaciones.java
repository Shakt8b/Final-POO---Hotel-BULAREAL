package hotelmanagementsystem.interfaz;

import hotelmanagementsystem.datos.HabitacionDatos;
import hotelmanagementsystem.model.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class FormHabitaciones extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    public FormHabitaciones() {
        setTitle("Gestión de Habitaciones");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        modelo = new DefaultTableModel(new String[]{"Número", "Piso", "Capacidad", "Precio", "Ocupada", "Tipo"}, 0);
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);

        JButton btnAgregar = new JButton("Agregar");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);

        add(scroll, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        cargarTabla();

        btnAgregar.addActionListener(e -> {
            try {
                String numeroStr = JOptionPane.showInputDialog(this, "Número habitación:");
                if (numeroStr == null) return;
                int numero = Integer.parseInt(numeroStr);

                String pisoStr = JOptionPane.showInputDialog(this, "Piso:");
                if (pisoStr == null) return;
                int piso = Integer.parseInt(pisoStr);

                String[] tipos = {"Sencilla", "Doble", "Suite", "Familiar", "Presidencial"};
                String tipoSel = (String) JOptionPane.showInputDialog(
                        this, "Tipo de habitación:", "Seleccionar",
                        JOptionPane.QUESTION_MESSAGE, null, tipos, tipos[0]
                );
                Habitacion nueva = crearHabitacionSegunTipo(tipoSel, numero, piso);
                if (nueva != null) HabitacionDatos.agregar(nueva);
                cargarTabla();
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Datos inválidos"); }
        });

        btnEditar.addActionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (fila == -1) { JOptionPane.showMessageDialog(this, "Seleccione una habitación"); return; }
            int numero = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
            Habitacion hab = HabitacionDatos.buscar(numero);
            if (hab == null) return;

            try {
                String pisoStr = JOptionPane.showInputDialog(this, "Nuevo piso:", hab.getPiso());
                if (pisoStr == null) return;
                int piso = Integer.parseInt(pisoStr);

                String[] tipos = {"Sencilla", "Doble", "Suite", "Familiar", "Presidencial"};
                String tipoSel = (String) JOptionPane.showInputDialog(
                        this, "Tipo de habitación:", "Seleccionar",
                        JOptionPane.QUESTION_MESSAGE, null, tipos, hab.getClass().getSimpleName()
                );

                Habitacion nueva = crearHabitacionSegunTipo(tipoSel, numero, piso);
                if (nueva != null) {
                    nueva.setOcupada(hab.isOcupada());
                    HabitacionDatos.actualizar(nueva);
                    cargarTabla();
                }

            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error al editar"); }
        });

        btnEliminar.addActionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (fila == -1) { JOptionPane.showMessageDialog(this, "Seleccione una habitación"); return; }
            int numero = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
            int conf = JOptionPane.showConfirmDialog(this, "Eliminar habitación " + numero + " ?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                HabitacionDatos.eliminar(numero);
                cargarTabla();
            }
        });
    }

    private void cargarTabla() {
        modelo.setRowCount(0);
        for (Habitacion h : HabitacionDatos.obtenerTodas()) {
            modelo.addRow(new Object[]{
                h.getNumero(), h.getPiso(), h.getCapacidad(), h.getPrecio(), h.isOcupada() ? "Sí" : "No", h.getClass().getSimpleName()
            });
        }
    }

    private Habitacion crearHabitacionSegunTipo(String tipo, int numero, int piso) {
        if (tipo == null) return null;
        switch (tipo.toLowerCase()) {
            case "sencilla": return new Sencilla(numero, piso);
            case "doble": return new Doble(numero, piso);
            case "suite": return new Suite(numero, piso);
            case "familiar": return new Familiar(numero, piso);
            case "presidencial": return new Presidencial(numero, piso);
            default: return null;
        }
    }
}
