package hotelmanagementsystem.interfaz;

import hotelmanagementsystem.datos.ReservaDatos;
import hotelmanagementsystem.datos.HuespedDatos;
import hotelmanagementsystem.model.Reserva;
import hotelmanagementsystem.model.Huesped;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class FormCheckIn extends JFrame {
    private JComboBox<String> cbReservas;

    public FormCheckIn() {
        setTitle("Check-In - HOTEL BULAREAL");
        setSize(450, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(5,5));

        cbReservas = new JComboBox<>();
        cargarReservas();

        JButton btn = new JButton("Realizar Check-In");
        btn.setBackground(new Color(0, 123, 255));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);

        add(new JLabel("Seleccione reserva:"), BorderLayout.NORTH);
        add(cbReservas, BorderLayout.CENTER);
        add(btn, BorderLayout.SOUTH);

        btn.addActionListener(e -> realizarCheckIn());
    }

    private void cargarReservas() {
        cbReservas.removeAllItems();
        List<Reserva> reservas = ReservaDatos.obtenerTodas();
        if (reservas.isEmpty()) cbReservas.addItem("No hay reservas");
        for (Reserva r: reservas) {
            cbReservas.addItem(r.getId().substring(0,8) + " | " + r.getNombreCliente() + " | Hab:" + r.getHabitacion().getNumero() + " | Pers:" + r.getPersonas());
        }
    }

    private void realizarCheckIn() {
        try {
            int idx = cbReservas.getSelectedIndex();
            if (idx < 0) return;
            Reserva r = ReservaDatos.obtenerTodas().get(idx);

            int cantidad = r.getPersonas();

            for (int i = 1; i <= cantidad; i++) {
                String nombre = JOptionPane.showInputDialog(this, "Nombre del huésped " + i + ":");
                if (nombre == null || nombre.isBlank()) nombre = r.getNombreCliente();

                String documento = JOptionPane.showInputDialog(this, "Documento de identificación del huésped " + i + ":");
                if (documento == null || documento.isBlank()) documento = r.getDocumento();

                String telefono = JOptionPane.showInputDialog(this, "Teléfono del huésped " + i + ":");
                if (telefono == null || telefono.isBlank()) telefono = r.getTelefono();

                Huesped h = new Huesped(nombre, documento, telefono, r.getEmail(), r.getHabitacion(), r.getNoches());
                HuespedDatos.agregar(h);
            }

            // Eliminar reserva y mantener habitación ocupada
            ReservaDatos.eliminarPorId(r.getId());

            JOptionPane.showMessageDialog(this, "Check-In completado para " + cantidad + " huésped(es).");
            dispose();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error en Check-In: " + ex.getMessage());
        }
    }
}
