package hotelmanagementsystem.interfaz;

import hotelmanagementsystem.datos.HabitacionDatos;
import hotelmanagementsystem.datos.ReservaDatos;
import hotelmanagementsystem.model.Habitacion;
import hotelmanagementsystem.model.PagoInfo;
import hotelmanagementsystem.model.Reserva;

import javax.swing.*;
import java.util.List;

public class FormReserva extends JFrame {

    private JTextField txtNombre, txtDocumento, txtTelefono, txtEmail, txtNoches, txtPersonas;
    private JComboBox<String> cbHabitaciones;

    public FormReserva() {
        setTitle("Hacer Reserva");
        setSize(480, 340);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JLabel l1 = new JLabel("Nombre:");
        l1.setBounds(20,20,120,25); add(l1);
        txtNombre = new JTextField(); txtNombre.setBounds(140,20,300,25); add(txtNombre);

        JLabel lDoc = new JLabel("Documento:"); lDoc.setBounds(20,60,120,25); add(lDoc);
        txtDocumento = new JTextField(); txtDocumento.setBounds(140,60,300,25); add(txtDocumento);

        JLabel lTel = new JLabel("Teléfono:"); lTel.setBounds(20,100,120,25); add(lTel);
        txtTelefono = new JTextField(); txtTelefono.setBounds(140,100,300,25); add(txtTelefono);

        JLabel lEmail = new JLabel("Email:"); lEmail.setBounds(20,140,120,25); add(lEmail);
        txtEmail = new JTextField(); txtEmail.setBounds(140,140,300,25); add(txtEmail);

        JLabel lPers = new JLabel("Personas:"); lPers.setBounds(20,180,120,25); add(lPers);
        txtPersonas = new JTextField("1"); txtPersonas.setBounds(140,180,80,25); add(txtPersonas);

        JLabel lNoches = new JLabel("Noches:"); lNoches.setBounds(240,180,80,25); add(lNoches);
        txtNoches = new JTextField("1"); txtNoches.setBounds(320,180,120,25); add(txtNoches);

        JLabel lHab = new JLabel("Habitación disponible:"); lHab.setBounds(20,220,150,25); add(lHab);
        cbHabitaciones = new JComboBox<>(); cbHabitaciones.setBounds(180,220,260,25); add(cbHabitaciones);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(100,260,120,35); add(btnBuscar);

        JButton btnGuardar = new JButton("Reservar");
        btnGuardar.setBounds(260,260,120,35); add(btnGuardar);

        btnBuscar.addActionListener(e -> cargarDisponibles());
        btnGuardar.addActionListener(e -> guardarReserva());
    }

    private void cargarDisponibles() {
        cbHabitaciones.removeAllItems();
        try {
            int personas = Integer.parseInt(txtPersonas.getText());
            List<Habitacion> dispon = HabitacionDatos.obtenerDisponibles(personas);
            if (dispon.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay habitaciones disponibles");
                return;
            }
            for (Habitacion h : dispon) {
                cbHabitaciones.addItem(h.getNumero() + " - " + h.getClass().getSimpleName() + " ($" + h.getPrecio() + ")");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ingrese número de personas válido");
        }
    }

    private void guardarReserva() {
        try {
            String nombre = txtNombre.getText().trim();
            String documento = txtDocumento.getText().trim();
            String telefono = txtTelefono.getText().trim();
            String email = txtEmail.getText().trim();
            int personas = Integer.parseInt(txtPersonas.getText());
            int noches = Integer.parseInt(txtNoches.getText());

            if (nombre.isEmpty() || documento.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nombre y documento son obligatorios");
                return;
            }

            if (cbHabitaciones.getItemCount() == 0) {
                JOptionPane.showMessageDialog(this, "Busque y seleccione una habitación");
                return;
            }

            String sel = (String) cbHabitaciones.getSelectedItem();
            int numero = Integer.parseInt(sel.split(" - ")[0]);

            Habitacion hab = HabitacionDatos.buscar(numero);
            if (hab == null) { JOptionPane.showMessageDialog(this, "Hab inválida"); return; }

            // Solicitar método de pago
            String[] metodos = {"Efectivo", "Tarjeta", "Transferencia"};
            String metodo = (String) JOptionPane.showInputDialog(this, "Seleccione método de pago:", "Pago",
                    JOptionPane.QUESTION_MESSAGE, null, metodos, metodos[0]);
            if (metodo == null) return;

            PagoInfo pago = new PagoInfo(metodo);

            switch (metodo) {
                case "Tarjeta":
                    pago.setTarjetaNumero(JOptionPane.showInputDialog("Número de tarjeta:"));
                    pago.setTarjetaNombre(JOptionPane.showInputDialog("Titular de la tarjeta:"));
                    pago.setTarjetaCVV(JOptionPane.showInputDialog("CVV:"));
                    break;
                case "Transferencia":
                    pago.setBancoTransferencia(JOptionPane.showInputDialog("Banco:"));
                    pago.setReferenciaTransferencia(JOptionPane.showInputDialog("Referencia:"));
                    break;
                case "Efectivo":
                    // No requiere datos adicionales
                    break;
            }

            Reserva r = new Reserva(nombre, documento, telefono, email, hab, noches, personas, pago);
            ReservaDatos.agregar(r);
            HabitacionDatos.marcarOcupada(hab.getNumero(), true);

            JOptionPane.showMessageDialog(this, "Reserva creada. ID: " + r.getId());
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al crear reserva: " + ex.getMessage());
        }
    }
}
