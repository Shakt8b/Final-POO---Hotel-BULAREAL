package hotelmanagementsystem.datos;

import hotelmanagementsystem.model.Servicio;
import java.util.ArrayList;
import java.util.List;

public class ServicioDatos {

    private static List<Servicio> servicios = new ArrayList<>();

    // Inicializamos algunos servicios base
    static {
        servicios.add(new Servicio("Minibar", 20000));
        servicios.add(new Servicio("Lavandería", 15000));
        servicios.add(new Servicio("Spa", 60000));
        servicios.add(new Servicio("Piscina VIP", 35000));
    }

    public static List<Servicio> obtenerTodos() {
        return servicios;
    }

    public static void agregar(Servicio servicio) {
        servicios.add(servicio);
    }

    public static void actualizar(String nombre, Servicio nuevo) {
        for (int i = 0; i < servicios.size(); i++) {
            if (servicios.get(i).getNombre().equalsIgnoreCase(nombre)) {
                servicios.set(i, nuevo);
                break;
            }
        }
    }

    public static void eliminar(String nombre) {
        servicios.removeIf(s -> s.getNombre().equalsIgnoreCase(nombre));
    }
}
