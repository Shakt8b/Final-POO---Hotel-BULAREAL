package hotelmanagementsystem.datos;

import hotelmanagementsystem.model.Reserva;
import java.util.ArrayList;
import java.util.List;

public class ReservaDatos {
    private static List<Reserva> reservas = new ArrayList<>();

    public static void agregar(Reserva r) { reservas.add(r); }

    public static List<Reserva> obtenerTodas() { return new ArrayList<>(reservas); }

    public static Reserva buscarPorId(String id) {
        for (Reserva r : reservas) if (r.getId().equals(id)) return r;
        return null;
    }

    public static boolean eliminarPorId(String id) {
        return reservas.removeIf(r -> r.getId().equals(id));
    }

    public static Reserva buscarPorNombre(String nombre) {
        for (Reserva r: reservas) if (r.getNombreCliente().equalsIgnoreCase(nombre)) return r;
        return null;
    }
}
