package hotelmanagementsystem.datos;

import hotelmanagementsystem.model.Huesped;
import java.util.ArrayList;
import java.util.List;

public class HuespedDatos {
    private static List<Huesped> huespedes = new ArrayList<>();

    public static void agregar(Huesped h) { huespedes.add(h); }

    public static List<Huesped> obtenerTodos() { return new ArrayList<>(huespedes); }

    public static boolean eliminar(Huesped h) { return huespedes.remove(h); }
}
