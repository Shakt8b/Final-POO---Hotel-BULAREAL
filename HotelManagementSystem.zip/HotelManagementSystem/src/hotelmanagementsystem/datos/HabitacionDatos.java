package hotelmanagementsystem.datos;

import hotelmanagementsystem.model.*;
import java.util.ArrayList;
import java.util.List;

public class HabitacionDatos {
    public static List<Habitacion> habitaciones = new ArrayList<>();

    static {
        habitaciones.add(new Sencilla(101,1));
        habitaciones.add(new Doble(102,1));
        habitaciones.add(new Suite(103,1));
        habitaciones.add(new Familiar(201,2));
        habitaciones.add(new Presidencial(301,3));
    }

    public static List<Habitacion> obtenerTodas() { return habitaciones; }

    public static List<Habitacion> obtenerDisponibles(int personas) {
        List<Habitacion> res = new ArrayList<>();
        for (Habitacion h : habitaciones) {
            if (!h.isOcupada() && h.getCapacidad() >= personas) res.add(h);
        }
        return res;
    }

    public static Habitacion buscar(int numero) {
        for (Habitacion h : habitaciones) if (h.getNumero() == numero) return h;
        return null;
    }

    public static void agregar(Habitacion h) { habitaciones.add(h); }

    public static boolean actualizar(Habitacion habitacionActualizada) {
        for (int i=0;i<habitaciones.size();i++) {
            if (habitaciones.get(i).getNumero() == habitacionActualizada.getNumero()) {
                habitaciones.set(i, habitacionActualizada); return true;
            }
        }
        return false;
    }

    public static boolean eliminar(int numero) { return habitaciones.removeIf(h -> h.getNumero() == numero); }

    public static void marcarOcupada(int numero, boolean estado) {
        Habitacion h = buscar(numero);
        if (h != null) h.setOcupada(estado);
    }
}
